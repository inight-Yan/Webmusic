# Edge 扩展开发记录

## manifest.json